#!/usr/bin/env/python
# 
# Version 1.0.0 -- 9/25/03
# Version 1.0.1 -- 4/09/04  -- fixed spelling of booleans
# Version 1.0.2 -- 7/15/04  -- Ignore blank lines
#
""" Routines for parsing SExtractor-style input files.

__author__ =  'Henry C. Ferguson'
__version__=  '1.0.3'
""" 

 
import string

def parseconfig(configfile,paramdict={},booleans=[]):
  """ Parse a file of format: PARAMETER   value  # comment
      into a dictionary
    
      Arguments:
      configfile -- input file name
      paramdict  -- dictionary of paramters (can be empty or already 
                    initialized to default values) 
      booleans   -- list of boolean parameters 
  """
  f = open(configfile,'r')
  lines = f.readlines()
  f.close()
  for l in lines:
    if len(l) > 1:
        ll = string.replace(l,',',' ') # Relace commas with spaces
        a = string.split(ll)
        if a[0][0] != '#':
         # If there is more than one value then make a list
         if len(a) > 2 and a[2][0] != '#':
           for i in range(2,len(a)):
             end = i
             if a[i][0] == '#':
               break;
           b = a[1:end]
           values = []
           for v in b:
             try:
               value = int(v)
             except:
               try:
                 value = float(v)
               except:
                 value = v
             values = values + [value]
           paramdict[a[0]] = values
     
         # Otherwise get just the one value
         else:
           try:
             value = int(a[1])
           except:
             try:
               value = float(a[1])
             except:
               value = a[1]
               if a[0] in booleans:
                 if value[0] == 'N' or value[0] == 'n':
                   value=0
                 else:
                   value=1
           paramdict[a[0]] = value                          
        # This logic overrides the above conversions in the case where
        # the argument is a string indicated by quotations
        a = string.split(l)
        if len(a) > 1: 
          if a[1][0] == "\"" or a[1][0] == "\'":
            paramdict[a[0]]= a[1][1:-1]
   
  return paramdict                                       
