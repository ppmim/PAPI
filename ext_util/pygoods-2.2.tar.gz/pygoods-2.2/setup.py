#! /usr/bin/env python

from distutils.core import setup

setup(name='pygoods',
   version='2.2',
   description='Python astronomical utilities for the GOODS project',
   author='Henry C. Ferguson, STScI',
   author_email='ferguson@stsci.edu',
   url='http://www.stsci.edu/~ferguson/software',
   packages=['pygoods'],
   license='BSD:LICENSE.txt'
)
