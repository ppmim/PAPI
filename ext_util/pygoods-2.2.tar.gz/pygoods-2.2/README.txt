Pygoods is a set of handy python utilities developed for
the Great Observatories Origins Deep Survey 
(http://www.stsci.edu/science/goods).

It includes some simple utilities for the following:
    - reading and writing columnar data to and from numpy arrays
    - dealing with SExtractor parameter files and catalogs
    - parsing astronomical coordinates and doing coordinate matching
    - cosmological distance calculations

To install into the standard system locations:

python setup.py install

To install into your own home directory:
If they don't exist, create:
   $HOME/lib
   $HOME/lib/python
   $HOME/bin
Then
   python setup.py install --home=$HOME

Put $HOME/bin in your PATH and $HOME/lib/python in your PYTHONPATH.

